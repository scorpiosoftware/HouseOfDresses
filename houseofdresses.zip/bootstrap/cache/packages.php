<?php return array (
  'codezero/browser-locale' => 
  array (
    'providers' => 
    array (
      0 => 'CodeZero\\BrowserLocale\\Laravel\\BrowserLocaleServiceProvider',
    ),
  ),
  'codezero/laravel-localized-routes' => 
  array (
    'providers' => 
    array (
      0 => 'CodeZero\\LocalizedRoutes\\LocalizedRoutesServiceProvider',
    ),
    'aliases' => 
    array (
      'LocaleConfig' => 'CodeZero\\LocalizedRoutes\\Facades\\LocaleConfig',
    ),
  ),
  'codezero/laravel-uri-translator' => 
  array (
    'providers' => 
    array (
      0 => 'CodeZero\\UriTranslator\\UriTranslatorServiceProvider',
    ),
  ),
  'laravel/breeze' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Breeze\\BreezeServiceProvider',
    ),
  ),
  'laravel/sail' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Sail\\SailServiceProvider',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'livewire/livewire' => 
  array (
    'providers' => 
    array (
      0 => 'Livewire\\LivewireServiceProvider',
    ),
    'aliases' => 
    array (
      'Livewire' => 'Livewire\\Livewire',
    ),
  ),
  'masoudi/laravel-visitors' => 
  array (
    'providers' => 
    array (
      0 => 'Masoudi\\Laravel\\Visitors\\Providers\\VisitorServiceProvider',
    ),
  ),
  'nesbot/carbon' => 
  array (
    'providers' => 
    array (
      0 => 'Carbon\\Laravel\\ServiceProvider',
    ),
  ),
  'nunomaduro/collision' => 
  array (
    'providers' => 
    array (
      0 => 'NunoMaduro\\Collision\\Adapters\\Laravel\\CollisionServiceProvider',
    ),
  ),
  'nunomaduro/termwind' => 
  array (
    'providers' => 
    array (
      0 => 'Termwind\\Laravel\\TermwindServiceProvider',
    ),
  ),
  'pestphp/pest-plugin-laravel' => 
  array (
    'providers' => 
    array (
      0 => 'Pest\\Laravel\\PestServiceProvider',
    ),
  ),
);
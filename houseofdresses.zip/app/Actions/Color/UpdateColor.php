<?php

namespace App\Actions\Color;

class UpdateColor
{

}

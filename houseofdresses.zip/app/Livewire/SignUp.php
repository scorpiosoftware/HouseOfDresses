<?php

namespace App\Livewire;

use Livewire\Component;

class SignUp extends Component
{
    public function render()
    {
        return view('livewire.sign-up');
    }
}

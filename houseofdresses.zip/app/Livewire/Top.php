<?php

namespace App\Livewire;

use Livewire\Component;

class Top extends Component
{
    public function render()
    {
        return view('livewire.top');
    }
}

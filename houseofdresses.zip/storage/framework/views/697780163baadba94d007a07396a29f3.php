<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <?php if(session()->has('success')): ?>
        <div id="alert-border-3"
            class="flex items-center p-4 mb-4 text-green-800 border-t-4 border-green-300 bg-green-50 dark:text-green-400 dark:bg-gray-800 dark:border-green-800"
            role="alert">
            <svg class="flex-shrink-0 w-4 h-4" aria-hidden="true" xmlns="http://www.w3.org/2000/svg" fill="currentColor"
                viewBox="0 0 20 20">
                <path
                    d="M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5ZM9.5 4a1.5 1.5 0 1 1 0 3 1.5 1.5 0 0 1 0-3ZM12 15H8a1 1 0 0 1 0-2h1v-3H8a1 1 0 0 1 0-2h2a1 1 0 0 1 1 1v4h1a1 1 0 0 1 0 2Z" />
            </svg>
            <div class="ms-3 text-sm font-medium">
                <?php echo e(session()->get('success')); ?>

            </div>
        </div>
    <?php endif; ?>
    <div class="text-2xl py-4 font-bold underline text-gray-900 dark:text-white">Invoices</div>
    <div class="relative m-4 md:flex justify-between items-center space-y-4">
        <form action="<?php echo e(route('invoice.index', 'status')); ?>" class="w-full max-w-md " method="GET">
            <select id="status" onchange="this.form.submit()" name="status"
                class="bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500">
                <option value="pending" <?php if(!empty($inputs['status']) and $inputs['status'] == 'pending'): ?> selected <?php endif; ?>>Pending</option>
                <option value="delivered" <?php if(!empty($inputs['status']) and $inputs['status'] == 'delivered'): ?> selected <?php endif; ?>>Delivered</option>
                <option value="canceled" <?php if(!empty($inputs['status']) and $inputs['status'] == 'canceled'): ?> selected <?php endif; ?>>Canceled</option>
            </select>
        </form>
        <form action="<?php echo e(route('invoice.index','search')); ?>" class="w-full max-w-md " method="GET">
            <label for="search" class="mb-2 text-sm font-medium text-gray-900 sr-only dark:text-white">Search</label>
            <div class="relative">
                <div class="absolute inset-y-0 start-0 flex items-center ps-3 pointer-events-none">
                    <svg class="w-4 h-4 text-gray-500 dark:text-gray-400" aria-hidden="true"
                        xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 20">
                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="m19 19-4-4m0-7A7 7 0 1 1 1 8a7 7 0 0 1 14 0Z" />
                    </svg>
                </div>
                <input type="search" id="search" name="search"
                    value="<?php if(!empty($inputs['search'])): ?> <?php echo e($inputs['search']); ?> <?php endif; ?>"
                    class="block w-full p-4 ps-10 text-sm text-gray-900 border border-gray-300 rounded-lg bg-gray-50 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                    placeholder="Search by category name ..." />
                <button type="submit"
                    class="text-white absolute end-2.5 bottom-2.5 bg-blue-700 hover:bg-blue-800 focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium rounded-lg text-sm px-4 py-2 dark:bg-blue-600 dark:hover:bg-blue-700 dark:focus:ring-blue-800">Search</button>
            </div>
        </form>



    </div>

    <div class="relative overflow-x-auto shadow-md sm:rounded-lg">
        <table class="w-full text-sm text-left rtl:text-right text-gray-500 dark:text-gray-400">
            <thead class="text-xs text-gray-700 uppercase text-nowrap bg-gray-50 dark:bg-gray-700 dark:text-gray-400">
                <tr>
                    <th scope="col" class="px-6 py-3">
                        ID
                    </th>
                    <th scope="col" class="px-6 py-3">
                        Customer Name
                    </th>
                    <th scope="col" class="px-6 py-3">
                        Customer Email
                    </th>
                    <th scope="col" class="px-6 py-3">
                        Customer Phone
                    </th>
                    <th scope="col" class="px-6 py-3">
                        Totle Amount
                    </th>
                    <th scope="col" class="px-6 py-3">
                        Order Date
                    </th>
                    <th scope="col" class="px-6 py-3">
                        Status
                    </th>
                    <th scope="col" class="px-6 py-3">
                        <span class="">Actions</span>
                    </th>

                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $records; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $record): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr class="relative bg-white border-b dark:bg-gray-800 dark:border-gray-700">

                        <td class="px-6 py-4 font-extrabold text-black text-base">
                            <?php if($record->status != 'canceled'): ?>
                            <div class="absolute z-40 opacity-0 hover:opacity-100">
                                <div class="flex justify-center items-center space-x-4">
                                    <?php if($record->status != 'delivered'): ?>
                                        <a href="<?php echo e(route('invoice.edit', $record->id)); ?>"
                                            class="px-3 bg-green-300 transition-all delay-75 hover:bg-green-400">Confirm</a>
                                    <?php endif; ?>
                                    <form action="<?php echo e(route('invoice.destroy', $record->id)); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?> 
                                        <button type="submit" class="px-3 bg-red-300 transition-all delay-75 hover:bg-red-400">Cancel Order</button>
                                    </form>
                                </div>

                            </div>
                            <?php endif; ?>
                            <?php echo e($record->auto_nb); ?>

                        </td>
                        <td class="px-6 py-4 font-bold text-black text-base text-nowrap">
                            <?php echo e($record->customer_name); ?>

                        </td>

                        <td class="px-6 py-4  text-black text-base text-nowrap">
                            <?php echo e($record->customer_email); ?>

                        </td>
                        <td class="px-6 py-4 text-black text-base text-nowrap">
                            <?php echo e($record->phone); ?>

                        </td>
                        <td class="px-6 py-4 font-extrabold text-green-400 text-base text-nowrap">
                            <?php echo e($record->total_amount); ?> $
                        </td>
                        <td class="px-6 py-4 font-extrabold text-green-400 text-base text-nowrap">
                            <?php echo e($record->order_date); ?>

                        </td>
                        <td
                            class="px-6 py-4 font-extrabold <?php if($record->status == 'delivered'): ?> text-green-400 <?php elseif($record->status == 'pending'): ?> text-orange-400 <?php endif; ?> text-base text-nowrap">
                            <?php echo e($record->status); ?>

                        </td>
                        <td class="px-6 py-3 mb-5 text-right flex justify-start items-center pt-[30px] space-x-4">
                            <a href="<?php echo e(route('invoice.show', $record->id)); ?>"
                                class="font-medium text-blue-600 dark:text-blue-500 hover:underline">Details</a>

                            <form action="<?php echo e(route('invoice.destroy', $record->id)); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button class=" text-red-600 hover:text-red-700">Cancel</button>
                            </form>
                        </td>


                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


            </tbody>
        </table>
        <nav aria-label="Page navigation example" class="p-4">
            <?php echo e($records->links()); ?>

        </nav>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH D:\Projects\houseofdresses\resources\views/dashboard/invoice/index.blade.php ENDPATH**/ ?>
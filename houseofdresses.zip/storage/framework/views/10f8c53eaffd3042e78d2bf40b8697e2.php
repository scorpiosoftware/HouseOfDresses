<div class="">
    <div class=" flex flex-wrap justify-center md:justify-start items-center">
        <form action="<?php echo e(route('shop.index')); ?>">
            <input class="hidden" type="text" name="collection" value="<?php if(!empty($collection)): ?><?php echo e($collection->name_en); ?><?php endif; ?>">
            <button type="submit" class="text-white ml-5 bg-[#b69357] px-3.5 py-2 rounded-xl leading-relaxed font-bold md:text-xl text-sm">SHOP NOW</button>
        </form>
        
    </div>
    <div class="text-center mx-auto md:text-4xl text-2xl basis-1/2 text-white font-bold drop-shadow-2xl pt-4 dancing-script">BEST SELLER</div>
    <div class="flex md:justify-center justify-start items-start space-x-3 overflow-x-auto mt-10 max-w-screen-2xl mx-auto">
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('product', ['product' => $product,'textcolor' => 'text-white','lazy' => true]);

$__html = app('livewire')->mount($__name, $__params, 'lw-1260187849-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?> 
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
    </div>
</div>

<?php /**PATH D:\Projects\houseofdresses\resources\views/livewire/product-slider.blade.php ENDPATH**/ ?>
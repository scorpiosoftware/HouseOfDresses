<div class="container p-2">
    <div class="horizontal-scrolling-items items-center">
        <div
            class="flex justify-start items-center horizontal-scrolling-items__item space-x-16 text-2xl text-[#b69357]  font-bold">
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="" class="hover:text-blue-400"><?php echo e($category->name_en); ?></a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    </div>
</div><?php /**PATH D:\Projects\houseofdresses\resources\views/livewire/category-scroll.blade.php ENDPATH**/ ?>
<div>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo e(env('APP_NAME')); ?></title>
    <link rel="icon" href="<?php echo e(URL::to('media/logo/jamesia.png')); ?>">
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,600&display=swap" rel="stylesheet" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/tom-select/dist/css/tom-select.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/tom-select/dist/js/tom-select.complete.min.js"></script>
    
    <link href="<?php echo e(URL::to('css/productSlider.css')); ?>" rel="stylesheet" />
    <!-- Libraries Stylesheet -->
    
    <script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.3.0/flowbite.min.js"></script>
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Styles -->
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css', 'resources/js/app.js'); ?>
</div>
<?php /**PATH D:\Projects\houseofdresses\resources\views/livewire/header.blade.php ENDPATH**/ ?>
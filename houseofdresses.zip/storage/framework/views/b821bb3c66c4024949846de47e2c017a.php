<img src="<?php echo e(URL::to('media/new/logo.png')); ?>" alt="" <?php echo e($attributes); ?>>

<?php /**PATH D:\Projects\houseofdresses\resources\views/components/application-logo.blade.php ENDPATH**/ ?>
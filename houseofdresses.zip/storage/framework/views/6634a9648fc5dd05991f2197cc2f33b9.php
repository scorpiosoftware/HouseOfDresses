<div>
    <div class="mt-10">
        <p>Size : <?php echo e($selected_size); ?></p>
        
        <div class="flex justify-start items-center space-x-2">
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $color->product->sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <button id="size_btn"
                    wire:click="setSize('<?php echo e($size->name); ?>')" wire:model="selected_size" onclick='this.classList.add("bg-[#b69357]","text-white","font-bold")' class="px-4 py-2.5 border <?php if($selected_size == $size->name): ?> bg-[#b69357] text-white font-bold <?php endif; ?>"><?php echo e($size->name); ?></button>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    </div>
    <div class="mt-10">
        <label for="qty" class="font-bold text-gray-600">QUANTITY</label>
        <input type="number" wire:model.live="qty"
            class="w-16 h-8 py-4 mx-6 shrink-0 border rounded-md border-gray-300 bg-transparent text-center text-sm font-medium text-gray-900 focus:outline-none focus:ring-0 dark:text-white"
            placeholder="" name="qty"
            <?php if(session('cart') && !empty($cart[$color->id]['quantity'])): ?> value="<?php echo e($cart[$color->id]['quantity']); ?>"  
             <?php else: ?>
             value='1' <?php endif; ?>
            min="<?php echo $color->minimum_quantity; ?>" max="<?php echo $color->maximum_quantity; ?>" />
    </div>

    <div class="flex justify-center items-center w-full bg-[#b69357] mt-10">
        <button wire:click='addToCart()' class="py-3 w-full rounded-lg hover:bg-gray-500 text-white font-bold">Add to
            Cart</button>
    </div>

    <div class="flex justify-center items-center w-full bg-[] mt-10">
        <button wire:click='addToWishlist()' id='wishlist_btn'>
            <div class="flex items-center justify-center space-x-2">
                <svg id="wishlist_svg" class="frcp-wishlist__icon" width="20px" height="20px" fill="black"
                    stroke="#b69357" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"
                    viewBox="0 0 24 24">
                    <path
                        d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z">
                    </path>
                </svg>
                <span class="font-bold text-base text-[#b69357]">Add to wishlist</span>
            </div>
        </button>
        <script>
            $(document).ready(function(){

                $('#wishlist_btn').click(function(){

                     $("#wishlist_svg").attr("fill",'#b69357')

                });

            });
        </script>
    </div>
</div>
<?php /**PATH D:\Projects\houseofdresses\resources\views/livewire/addtocart.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>

    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,500,600&display=swap" rel="stylesheet" />
    <link href="https://cdn.jsdelivr.net/npm/tom-select/dist/css/tom-select.css" rel="stylesheet" />
    <script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/tom-select/dist/js/tom-select.complete.min.js"></script>
    <link href="<?php echo e(URL::to('css/productSlider.css')); ?>" rel="stylesheet" />
    <!-- Scripts -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>

<body class="font-sans antialiased">
    <div class="min-h-screen bg-gray-100">
        <?php if (isset($component)) { $__componentOriginal44ef828bf42e5d75d82a60f3147dba4e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal44ef828bf42e5d75d82a60f3147dba4e = $attributes; } ?>
<?php $component = App\View\Components\Dashboard\Dashboard::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('dashboard.dashboard'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Dashboard\Dashboard::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal44ef828bf42e5d75d82a60f3147dba4e)): ?>
<?php $attributes = $__attributesOriginal44ef828bf42e5d75d82a60f3147dba4e; ?>
<?php unset($__attributesOriginal44ef828bf42e5d75d82a60f3147dba4e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal44ef828bf42e5d75d82a60f3147dba4e)): ?>
<?php $component = $__componentOriginal44ef828bf42e5d75d82a60f3147dba4e; ?>
<?php unset($__componentOriginal44ef828bf42e5d75d82a60f3147dba4e); ?>
<?php endif; ?>
        <!-- Page Content -->
        <main>
            <div class="p-4 sm:ml-64">
                <div class="p-4 border-2 border-gray-200 border-dashed rounded-lg dark:border-gray-700 mt-14">
                    <?php echo e($slot); ?>

                </div>
            </div>
        </main>
    </div>
</body>

</html>
<?php /**PATH D:\Projects\houseofdresses\resources\views/layouts/app.blade.php ENDPATH**/ ?>
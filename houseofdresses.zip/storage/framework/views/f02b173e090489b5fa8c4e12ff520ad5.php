
<?php $__env->startSection('content'); ?>
    <div class="max-w-6xl mx-auto mt-10">
        <div class="md:flex justify-start items-start mx-auto">
            <div class="hidden md:overflow-y-auto overflow-x-auto flex justify-start items-center md:grid md:grid-cols-1 md:max-h-[46rem] md:gap-y-2 gap-x-2 p-3 ">
                <?php $__currentLoopData = $record->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <img class="md:w-32 w-20 rounded-lg" src="<?php echo e(URL::to('storage/' . $image->image_url)); ?>" alt="">
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="w-96 mx-auto">
                <img src="<?php echo e(URL::to('storage/' . $record->images()->first()->image_url)); ?>" class="rounded-lg" alt="">
            </div>
            <div class="md:hidden md:overflow-y-auto overflow-x-auto flex justify-start items-center gap-x-2 px-4 py-2">
                <?php $__currentLoopData = $record->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <img class="md:w-32 w-28 rounded-lg" src="<?php echo e(URL::to('storage/' . $image->image_url)); ?>" alt="">
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="px-6 md:w-1/2">
                <p class="text-xl"><?php echo e($record->product->name_en); ?></p>
                <a href="/" class="text-lg font-semibold text-gray-600">HOD</a>
                <p class="text-lg text-gray-600">ADE <?php echo e($record->product->price); ?></p>
                <div class="flex flex-wrap justify-start items-center space-x-1">
                    <img src="<?php echo e(URL::to('media/new/visa.jpg')); ?>" class="w-12" alt="">
                    <img src="<?php echo e(URL::to('media/new/mastercard.jpg')); ?>" class="w-12" alt="">
                    <img src="<?php echo e(URL::to('media/new/pay.jpg')); ?>" class="w-12" alt="">
                    <img src="<?php echo e(URL::to('media/new/tabby.jpg')); ?>" class="w-12" alt="">
                </div>
                <div class="flex justify-start items-center space-x-1 mt-10">
                      <?php $__currentLoopData = $record->product->colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <a href="/shop/<?php echo e($color->id); ?>" class="rounded-full border-2 px-4 py-4 bg-[<?php echo e($color->color); ?>]"></a>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('addtocart', ['product' => $record->product,'color' => $record]);

$__html = app('livewire')->mount($__name, $__params, 'lw-2482898015-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Projects\houseofdresses\resources\views/shop/show.blade.php ENDPATH**/ ?>
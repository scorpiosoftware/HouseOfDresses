<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo e(env('APP_NAME')); ?></title>
    <link rel="icon" href="<?php echo e(URL::to('media/logo/jamesia.png')); ?>">
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,600&display=swap" rel="stylesheet" />
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <link href="https://cdn.jsdelivr.net/npm/tom-select/dist/css/tom-select.css" rel="stylesheet" />
    <script src="https://cdn.jsdelivr.net/npm/tom-select/dist/js/tom-select.complete.min.js"></script>
    <link href="<?php echo e(URL::to('css/productSlider.css')); ?>" rel="stylesheet" />
    <!-- Libraries Stylesheet -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.3.0/flowbite.min.js"></script>
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- Styles -->
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css', 'resources/js/app.js'); ?>
</head>

<body class="font-sans antialiased">
    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('news-lable', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-2266844190-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('navbar', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-2266844190-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('cart-menu', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-2266844190-2', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('menu', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-2266844190-3', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        <main>
            <div class="md:mt-64 mt-44"></div>
            <?php echo $__env->yieldContent('content'); ?>
            <br>
            <br>
        </main>
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('footer', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-2266844190-4', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            <?php if (isset($component)) { $__componentOriginal5256d2ade5d16f390bcfbc93f1a298cd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5256d2ade5d16f390bcfbc93f1a298cd = $attributes; } ?>
<?php $component = App\View\Components\Section\Scripts::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('section.scripts'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Section\Scripts::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5256d2ade5d16f390bcfbc93f1a298cd)): ?>
<?php $attributes = $__attributesOriginal5256d2ade5d16f390bcfbc93f1a298cd; ?>
<?php unset($__attributesOriginal5256d2ade5d16f390bcfbc93f1a298cd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5256d2ade5d16f390bcfbc93f1a298cd)): ?>
<?php $component = $__componentOriginal5256d2ade5d16f390bcfbc93f1a298cd; ?>
<?php unset($__componentOriginal5256d2ade5d16f390bcfbc93f1a298cd); ?>
<?php endif; ?>
</body>

</html>
<?php /**PATH D:\Projects\houseofdresses\resources\views/layouts/home.blade.php ENDPATH**/ ?>
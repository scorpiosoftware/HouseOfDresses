<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?php echo e(env('APP_NAME')); ?></title>
    <link rel="icon" href="<?php echo e(URL::to('media/logo/jamesia.png')); ?>">
    <!-- Fonts -->

    <link rel="preconnect" href="https://fonts.bunny.net">
    <link href="https://fonts.bunny.net/css?family=figtree:400,600&display=swap" rel="stylesheet" />
    
    <link href="<?php echo e(URL::to('css/productSlider.css')); ?>" rel="stylesheet" />
    <!-- Libraries Stylesheet -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/flowbite/2.3.0/flowbite.min.js"></script>
    <script src="https://cdn.tailwindcss.com"></script>


    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Dancing+Script&family=Playwrite+CU:wght@100..400&display=swap"
        rel="stylesheet">

    <!-- Styles -->
    <?php echo app('Illuminate\Foundation\Vite')('resources/css/app.css', 'resources/js/app.js'); ?>
</head>

<body class="antialiased bg-[#e4c7cb]" id="home">
    <style>
        .dancing-script {
            font-family: "Playwrite CU", cursive;
            font-optical-sizing: auto;
            font-weight: 400;
            font-style: normal;
        }
    </style>
    <div class="">
        <?php if(auth()->guard()->guest()): ?>
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('sign-up', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-2187433924-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            <?php endif; ?>
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('cart-menu', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-2187433924-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('menu', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-2187433924-2', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('news-lable', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-2187433924-3', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('navbar', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-2187433924-4', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('carousel', ['url' => 'carousel-2.jpg','title' => 'UNIQUE DRESSES','position' => 'top-[40%] right-1/3 z-40 translate-x-1/2 translate-y-1/2']);

$__html = app('livewire')->mount($__name, $__params, 'lw-2187433924-5', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('category-scroll', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-2187433924-6', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('carousel', ['url' => 'carousel-1.jpg','title' => 'LUXURY AHAYAS','position' => 'top-[40%] left-20 z-40 translate-y-1/2']);

$__html = app('livewire')->mount($__name, $__params, 'lw-2187433924-7', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                                        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('categorywithimage', ['lazy' => true]);

$__html = app('livewire')->mount($__name, $__params, 'lw-2187433924-8', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                                            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('product-slider', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-2187433924-9', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                                                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('post-section', ['posts' => $posts]);

$__html = app('livewire')->mount($__name, $__params, 'lw-2187433924-10', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                                                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('footer', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-2187433924-11', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                                                        <?php if (isset($component)) { $__componentOriginal42e412826cab5e36b170ed987bbbd9a2 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal42e412826cab5e36b170ed987bbbd9a2 = $attributes; } ?>
<?php $component = App\View\Components\Home\SpeedDial::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('home.speed-dial'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Home\SpeedDial::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal42e412826cab5e36b170ed987bbbd9a2)): ?>
<?php $attributes = $__attributesOriginal42e412826cab5e36b170ed987bbbd9a2; ?>
<?php unset($__attributesOriginal42e412826cab5e36b170ed987bbbd9a2); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal42e412826cab5e36b170ed987bbbd9a2)): ?>
<?php $component = $__componentOriginal42e412826cab5e36b170ed987bbbd9a2; ?>
<?php unset($__componentOriginal42e412826cab5e36b170ed987bbbd9a2); ?>
<?php endif; ?>
                                                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('top', []);

$__html = app('livewire')->mount($__name, $__params, 'lw-2187433924-12', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    </div>
    </div>
    <?php if (isset($component)) { $__componentOriginal5256d2ade5d16f390bcfbc93f1a298cd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5256d2ade5d16f390bcfbc93f1a298cd = $attributes; } ?>
<?php $component = App\View\Components\Section\Scripts::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('section.scripts'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Section\Scripts::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5256d2ade5d16f390bcfbc93f1a298cd)): ?>
<?php $attributes = $__attributesOriginal5256d2ade5d16f390bcfbc93f1a298cd; ?>
<?php unset($__attributesOriginal5256d2ade5d16f390bcfbc93f1a298cd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5256d2ade5d16f390bcfbc93f1a298cd)): ?>
<?php $component = $__componentOriginal5256d2ade5d16f390bcfbc93f1a298cd; ?>
<?php unset($__componentOriginal5256d2ade5d16f390bcfbc93f1a298cd); ?>
<?php endif; ?>
</body>

</html>
<?php /**PATH D:\Projects\houseofdresses\resources\views/welcome.blade.php ENDPATH**/ ?>
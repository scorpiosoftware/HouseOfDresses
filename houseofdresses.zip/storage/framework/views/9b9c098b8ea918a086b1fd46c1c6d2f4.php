<div class="md:px-0 px-10">
    <div id="filter"
        class="max-w-3xl mx-auto border-2 md:flex md:flex-wrap md:gap-4 justify-start items-center px-10 py-2 mt-10">
        <div class="">
            <label for="categories"
                class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Categories</label>
            <div class="relative flex w-full">
                <select id="categories" name="categories" wire:model='selected_categories'
                    placeholder="Select Category..." autocomplete="off"
                    class="block w-full border-2 border-[#b69357] p-1 text-xs rounded-lg cursor-pointer focus:outline-none">
                    <option value=""></option>
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($cat->id); ?>"><?php echo e($cat->name_en); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->

                </select>
            </div>
        </div>
        <div class="">
            <label for="sizes" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">Sizes</label>
            <div class="relative flex w-full">
                <select id="sizes" name="sizes[]" wire:model='selected_sizes' placeholder="Select Size..."
                    autocomplete="off"
                    class="block w-full border-2 border-[#b69357] p-1 text-xs rounded-lg cursor-pointer focus:outline-none">
                    <option value=""></option>
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($size->id); ?>"><?php echo e($size->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->

                </select>
            </div>
        </div>
        <div class="">
            <label for="colors" class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">colors</label>
            <div class="relative flex w-full">
                <select id="colors" name="colors[]" wire:model='selected_colors' placeholder="Select Colors..."
                    autocomplete="off"
                    class="block w-full border-2 border-[#b69357] p-1 text-xs rounded-lg cursor-pointer focus:outline-none">
                    <option value=""></option>
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $colors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $color): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($color->id); ?>"><?php echo e($color->name); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->

                </select>
            </div>
        </div>
        <div class="">
            <label for="collections"
                class="block mb-2 text-sm font-medium text-gray-900 dark:text-white">collections</label>
            <div class="relative flex w-full">
                <select id="collections" name="collections" wire:model='selected_collection'
                    placeholder="Select Collection..." autocomplete="off"
                    class="block w-full border-2 border-[#b69357] p-1 text-xs rounded-md cursor-pointer focus:outline-none">
                    <option value=""></option>
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $collections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $collection): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($collection->id); ?>"><?php echo e($collection->name_en); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                </select>
            </div>
        </div>
        <div class="pt-[27px]">
            <button wire:click='filter()'
                class="border-[#b69357] bg-[#b69357] text-white border-2 px-4 py-[2px]">Apply</button>
        </div>
    </div>

    <div class="max-w-6xl  grid md:grid-cols-4 items-start mt-12 md:mx-auto mx-8 grid-cols-2 gap-x-2">
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('product', ['product' => $product,'textcolor' => 'text-black']);

$__html = app('livewire')->mount($__name, $__params, 'lw-801397163-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
    </div>


</div>
<?php /**PATH D:\Projects\houseofdresses\resources\views/livewire/product-show.blade.php ENDPATH**/ ?>
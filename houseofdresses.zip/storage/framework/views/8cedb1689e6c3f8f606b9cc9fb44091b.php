<div class="flex justify-start items-center space-x-4 ">
    <div class="md:w-64 w-44 ">
        <a href="<?php echo e(route('shop.show', $product->colors()->first()->id)); ?>">
            <div class="relative">
                <img class="relative mx-auto md:w-64 w-56 object-cover rounded-lg"
                    src="<?php echo e(URL::to('storage/' . $product->colors()->first()->main_image_url)); ?>" alt="">
                    <!--[if BLOCK]><![endif]--><?php if($product->colors->count() > 0 && $product->colors->first()->images->count() > 0 ): ?>
                    <img class="absolute top-0 mx-auto w-full  opacity-0 transition-opacity delay-150 hover:opacity-100 rounded-lg"
                    src="  <?php echo e(URL::to('storage/' . $product->colors()->first()->images()->first()->image_url)); ?>"
                    alt="">
                    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            </div>
        </a>
        <h3 class="text-center <?php echo e($textcolor); ?>  font-bold text-xl underline leading-loose underline-offset-8 drop-shadow-2xl">
            <?php echo e($product->categories()->first()->name_en); ?></h3>
        <h3 class="text-center text-[#b69357] font-bold text-lg"><?php echo e($product->name_en); ?></h3>
        <h3 class="text-center"><span class="text-[#b69357] font-bold text-lg" data-amount="799">
            <!--[if BLOCK]><![endif]--><?php if(session('currency') == 'ade'): ?>
            ADE <?php echo e($product->price2); ?>

            <?php else: ?>
            USD <?php echo e($product->price); ?>

            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                
            </h3>
        <div class="flex justify-center items-center space-x-3">
            <ul data-option-index="0" class="flex items-center justify-center space-x-2 py-2">
                <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $product->sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li data-option-title="S"
                        class="px-2 border-2 bg-white text-[#b69357] font-bold rounded-lg hover:text-white hover:bg-[#b69357]">
                        <a href="<?php echo e(route('shop.show', $product->colors()->first()->id)); ?>"><?php echo e(strtoupper($size->name)); ?></a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
            </ul>
        </div>
    </div>
</div>
<?php /**PATH D:\Projects\houseofdresses\resources\views/livewire/product.blade.php ENDPATH**/ ?>
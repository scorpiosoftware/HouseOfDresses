<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
{{-- <script src="https://cdn.jsdelivr.net/npm/flowbite@2.5.1/dist/flowbite.min.js"></script> --}}
<script src="/lib/wow/wow.min.js"></script>
<script src="https://cdn.ckeditor.com/4.16.2/standard/ckeditor.js"></script>

<script src="/js/main.js"></script>
{{-- <script src="/js/tom_select.js"></script> --}}
<script src="/js/lang.js"></script>
<script src="/js/toast.js"></script>

<img src="{{ URL::to('media/new/logo.png') }}" alt="" {{ $attributes }}>


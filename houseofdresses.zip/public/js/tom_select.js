new TomSelect('#categories', {
    minItems: 1,
});

new TomSelect('#colors', {
    minItems: 1,
});

new TomSelect('#sizes', {
    minItems: 1,
});

new TomSelect('#collections', {
    maxItems: 1,
});
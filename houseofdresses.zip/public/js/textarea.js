CKEDITOR.replace('description');
CKEDITOR.replace('description_ar');
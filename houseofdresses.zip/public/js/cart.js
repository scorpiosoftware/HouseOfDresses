function loadcart(){
    $.ajax({
        method: "GET",
        url: "/"
    })
}

